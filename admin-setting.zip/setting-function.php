<?php
/*
Plugin Name: RanOnlineVN.Com
Description: Cài đặt trang web dành cho RanOnlineVN.com
Author: Nguyễn Hoàng Duy
*/
  class Submenu {
  
    /**
    * A reference the class responsible for rendering the submenu page.
    *
    * @var    Submenu_Page
    * @access private
    */
    private $submenu_page;

    /**
    * Initializes all of the partial classes.
    *
    * @param Submenu_Page $submenu_page A reference to the class that renders the
    *                                                                   page for the plugin.
    */
    public function __construct( $submenu_page ) {
      $this->submenu_page = $submenu_page;
    }

    /**
    * Adds a submenu for this plugin to the 'Tools' menu.
    */
    public function init() {
      add_action( 'admin_menu', array( $this, 'add_options_page' ) );
    }

    /**
    * Creates the submenu item and calls on the Submenu Page object to render
    * the actual contents of the page.
    */
    public function add_options_page() {

      add_options_page(
          'Thiết lập cài đặt Ran Online VN',
          'Ran Online',
          'manage_options',
          'custom-admin-page',
          array( $this->submenu_page, 'render' )
      );
    }
  }
  class Submenu_Page {
 
    /**
     * This function renders the contents of the page associated with the Submenu
     * that invokes the render method. In the context of this plugin, this is the
     * Submenu class.
     */
    public function render() {
      return include("includes/setting-page.php");
    }
  }


if ( ! defined( 'WPINC' ) ) {
     die;
}


 
// Include the dependencies needed to instantiate the plugin.
foreach ( glob( plugin_dir_path( __FILE__ ) . 'admin-setting/*.php' ) as $file ) {
    include_once $file;
}
register_activation_hook( __FILE__, 'hook' );
register_deactivation_hook( __FILE__, 'unhook' );
add_action( 'plugins_loaded', 'tutsplus_custom_admin_settings' );
function tutsplus_custom_admin_settings() {
  $plugin = new Submenu( new Submenu_Page() );
  $plugin->init();
}
function unhook(){
  require_once(ABSPATH . 'wp-config.php');
  $connection = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD);
  mysqli_select_db($connection, DB_NAME);
  $connection -> query("DROP TABLE IF EXISTS admin_setting");
}
function hook(){
  require_once(ABSPATH . 'wp-config.php');
  $connection = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD);
  mysqli_select_db($connection, DB_NAME);
  $connection -> query("CREATE table if not EXISTS admin_setting (setting_key VARCHAR(50) PRIMARY KEY,setting_value VARCHAR(500) NOT NULL,description VARCHAR(500) NOT NULL)");
  // Insert default setting
  $connection -> query("INSERT INTO `wordpress`.`admin_setting`(`setting_key`, `setting_value`, `description`) VALUES ('background', 'http://admin.ranonlinevn.com/wp-content/uploads/2020/08/bg.jpg', 'Hình nền');");
  $connection -> query("INSERT INTO `wordpress`.`admin_setting`(`setting_key`, `setting_value`, `description`) VALUES ('banner', 'http://admin.ranonlinevn.com/wp-content/uploads/2020/08/ran-world.png', 'Banner');");
  $connection -> query("INSERT INTO `wordpress`.`admin_setting`(`setting_key`, `setting_value`, `description`) VALUES ('download', 'https://google.com', 'Tải game');");
  $connection -> query("INSERT INTO `wordpress`.`admin_setting`(`setting_key`, `setting_value`, `description`) VALUES ('run', 'abc.exe', 'File vào game');");
  $connection -> query("INSERT INTO `wordpress`.`admin_setting`(`setting_key`, `setting_value`, `description`) VALUES ('run_args', '', 'Tham số file vào game');");
  $connection -> query("INSERT INTO `wordpress`.`admin_setting`(`setting_key`, `setting_value`, `description`) VALUES ('main_image', 'http://www.americanlayout.com/wp/wp-content/uploads/2012/08/C-To-Go-300x300.png', 'Hình ảnh dọc trên launcher');");
}